
1.
CREATE TABLE doctor_appointment(appointment_id Number(4) PRIMARY KEY, patie
nt_name VARCHAR2(20), phone_number VARCHAR2(10),date_of_appointment DATE, email
VARCHAR2(50), age NUMBER(2), gender VARCHAR2(6), problem_name VARCHAR2(25),docto
r_name VARCHAR2(25),appointment_status VARCHAR2(11));

Table created.

SQL> desc doctor_appointment;
 Name                                      Null?    Type
 ----------------------------------------- -------- ----------------------------

 APPOINTMENT_ID                            NOT NULL NUMBER(4)
 PATIENT_NAME                                       VARCHAR2(20)
 PHONE_NUMBER                                       VARCHAR2(10)
 DATE_OF_APPOINTMENT                                DATE
 EMAIL                                              VARCHAR2(50)
 AGE                                                NUMBER(2)
 GENDER                                             VARCHAR2(6)
 PROBLEM_NAME                                       VARCHAR2(25)
 DOCTOR_NAME                                        VARCHAR2(25)
 APPOINTMENT_STATUS                                 VARCHAR2(11)

 2.
CREATE SEQUENCE seq_appointment_id START WITH 1001;

Sequence created.

