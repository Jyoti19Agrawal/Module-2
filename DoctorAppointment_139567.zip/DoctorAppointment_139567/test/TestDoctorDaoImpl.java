import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.exception.ClientException;

public class TestDoctorDaoImpl
{
	static DoctorAppointmentDao clientDao;
	static DoctorAppointment clientBean;

	/**************************************
	 * It will call before class loaded 
	 *  to memory
	 * 
	 **************************************/
	@BeforeClass
	public static void beforeClass()
	{
		clientDao =new DoctorAppointmentDao();
		clientBean = new DoctorAppointment();
	}
	

	/**************************************
	 * Test case for addpatientAppointment()
	 * 
	 **************************************/

	@Test
	public void testAddPatientDetails() throws ClientException
	{
		assertNotNull(clientDao.addpatientAppointment(clientBean));
	}
	

	/**************************************
	 * Test case for addpatientAppointment()
	 * 
	 **************************************/

	@Test
	public void testAddPatient() throws ClientException
	{
		clientBean.setPatient_name("Kishan");
		clientBean.setPhone_number("9898767698");;
		clientBean.setEmail("abc@gmail.com");
		clientBean.setAge(25);
		clientBean.setGender("male");
		clientBean.setProblem_name("Heart");
		int id = clientDao.addpatientAppointment(clientBean);
		assertTrue(id>0);
	}

	/**************************************
	 * Test case for addpatientAppointment()
	 * 
	 **************************************/
	@Ignore
	@Test
	public void testAddPatientDetails1() throws ClientException {
		// increment the number next time you test for positive test case
		assertEquals(1001, clientDao.addpatientAppointment(clientBean));
	}
	

	/************************************
	 * Test case for ViewStatusById()
	 * 
	 ************************************/
	@Test
	public void testViewStatusById() throws ClientException
	{
		assertNotNull(clientDao.viewStatusById(1006));
	}

	/************************************
	 * Test case for ViewStatusById()
	 * 
	 ************************************/
	@Test
	public void testViewStatusById1() throws ClientException {
		assertEquals("Dhruvi", clientDao.viewStatusById(1006).getPatient_name());
	}
	
}
