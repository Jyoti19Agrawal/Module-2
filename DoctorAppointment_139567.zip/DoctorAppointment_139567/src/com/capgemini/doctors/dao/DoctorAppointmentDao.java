package com.capgemini.doctors.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.ClientException;
import com.capgemini.doctors.util.DBConnection;

/**************************************************************************************
 *  - Class			    : DoctorAppointmentDao
 *  - Author		    : DHRUVI DOSHI 
 *  - Creation Date     : 30/11/2017
 *  - Description       : Connect to database and Execute query 
 ***************************************************************************************/

public class DoctorAppointmentDao implements IDoctorAppointmentDao {

	Logger logger = Logger.getLogger(DoctorAppointmentDao.class);
	
	public DoctorAppointmentDao()
	{
		PropertyConfigurator.configure("resources/log4j.properties");
	}
	
/*************************************************************************************
 *  - Method 			: generateClientId()
 *  - Input Parameters  : 
 *  - Return Type 		: integer
 *  - Author		    : DHRUVI DOSHI 
 *  - Creation Date     : 30/11/2017
 *  - Description       : generate appointment_id from sequence
 ***************************************************************************************/
	
	public int generateClientId()
	{
		int id=0;
		Connection  con = null;
		String str= "select seq_appointment_id.nextval from dual";
		try 
		{
			logger.info("connecting to database for generating client id..");
			con=DBConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(str);
			rs.next();
			id=rs.getInt(1);
			logger.info("id generated..\n");
		}
		catch (Exception e) 
		{
			logger.info("id can not be generated..\n");
			System.out.println("id can not generated.try again!");
		}
		return id;
	}
	
	
/*************************************************************************************
 *  - Method 			: addpatientAppointment()
 *  - Input Parameters  : DoctorAppointment
 *  - Return Type 		: integer
 *  - Author		    : DHRUVI DOSHI 
 *  - Creation Date     : 30/11/2017
 *  - Description       : insert appointment details from user
 ***************************************************************************************/	
	
	@Override
	public int addpatientAppointment(DoctorAppointment bean) throws ClientException {
		int id=0;
		Connection con= null;
		
		String cmd="insert into doctor_appointment values(?,?,?,sysdate+2,?,?,?,?,?,?)";
		
		try 
		{
			logger.debug("connecting to database for adding appointment details from client..");
			con=DBConnection.getConnection();
			id=generateClientId();
			String problemName= bean.getProblem_name();
			System.out.println(problemName);
			
			String status = null;
			String docName = null;
			
			if(problemName.equalsIgnoreCase("Heart"))
			{
				status= "Approved";
			    docName="Dr.Brijesh Kumar";
			}
			
			else if(problemName.equalsIgnoreCase("Gynecology"))
			{
				status="Approved";
				 docName="Dr.Sharda Singh";
			}
			
			else if(problemName.equalsIgnoreCase("Diabetes"))
			{
				status="Approved";
				 docName="Heena Khan";
			}
			
			else if(problemName.equalsIgnoreCase("ENT"))
			{
				status="Approved";
				docName="Dr.Paras Mel";
			}
			
			else if(problemName.equalsIgnoreCase("Bone"))
			{
				status="Approved";
				 docName="Dr.Renuka Kher";
			}
			
			else if(problemName.equalsIgnoreCase("Dermatology"))
			{
				status="Approved";
				 docName="Dr.Kanika Kapoor";
			}
			
			else
			{
				status="Disapproved";
				 docName="";
			}
			
			PreparedStatement ps = con.prepareStatement(cmd);
			
			ps.setInt(1,id);
			ps.setString(2,bean.getPatient_name());
			ps.setString(3, bean.getPhone_number());
			ps.setString(4, bean.getEmail());
			ps.setInt(5, bean.getAge());
			ps.setString(6, bean.getGender());
			ps.setString(7, bean.getProblem_name());
			ps.setString(8, docName);
			ps.setString(9, status);
			
			int n=ps.executeUpdate();
			System.out.println(n);
			if(n==0)
			{
				logger.error("exception while adding patient details to database..\n");
				throw new ClientException("Unable to add to database");
			}
			con.close();
		}
		
		catch (Exception e) 
		{
			e.printStackTrace();
			logger.error("exception while adding details..\n");
			throw new ClientException("Client id not found");
		} 
		return id;
	}

	
/*************************************************************************************
 *  - Method 			: viewStatusById()
 *  - Input Parameters  : integer
 *  - Return Type 		: DoctorAppointment
 *  - Author		    : DHRUVI DOSHI 
 *  - Creation Date     : 30/11/2017
 *  - Description       : display appointment status details to user
 ***************************************************************************************/	
	
	@Override
	public DoctorAppointment viewStatusById(int viewId) throws ClientException
	{
		Connection con= null;
		Statement stmt =null;
		DoctorAppointment bean= new DoctorAppointment();
		
		try {
			logger.debug("connecting to database for viewing status of appointment by id..");
			con=DBConnection.getConnection();
			String cmd="select patient_name,appointment_status,doctor_name,date_of_appointment from doctor_appointment where appointment_id ="+ viewId;
			 stmt =con.createStatement();

			 ResultSet result =stmt.executeQuery(cmd);
			 if(result.next())
				{
				 	bean.setPatient_name(result.getString(1));
					bean.setAppointment_status(result.getString(2));
					bean.setDoctor_name(result.getString(3));
					bean.setDate_of_appointment(result.getDate(4));
					logger.info("details fetched from doctor_appointment table table..\n");	
				}
			 else
			 {
				 logger.error("exception while fetching details..\n");
				 throw new ClientException("Id not found!");
			 }
			 con.close();
		}
		 catch (SQLException e) 
		{
			System.out.println("database error!");
		}
		return bean;	
	}

}
