package com.capgemini.doctors.dao;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.ClientException;

/**************************************************************************************
 *  - Interface		    : IDoctorAppointmentDao
 *  - Methods           : addPatientAppointment(),viewStatusById()
 *  - Author		    : DHRUVI DOSHI 
 *  - Creation Date     : 30/11/2017
 *  - Description       : Connect to database and Execute query 
 ***************************************************************************************/
public interface IDoctorAppointmentDao {

	public int addpatientAppointment(DoctorAppointment bean) throws ClientException;
	public DoctorAppointment viewStatusById(int viewId) throws ClientException;
}
