package com.capgemini.doctors.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.IDoctorAppointmentDao;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.exception.ClientException;

	/**************************************************************************************
	 *  - Class			    : DoctorAppointmentService
	 *  - Parent interface  : IDoctorAppointmentDao
	 *  - Author		    : DHRUVI DOSHI 
	 *  - Creation Date     : 30/11/2017
	 *  - Description       : Add patient details and view status details
	 ***************************************************************************************/

public class DoctorAppointmentService implements IDoctorAppointmentService {

	private IDoctorAppointmentDao patientDao = new DoctorAppointmentDao();
	
	@Override
	public int addpatientAppointment(DoctorAppointment bean) throws ClientException {
		int id=  patientDao.addpatientAppointment(bean);
		return id;
	}
	/*************************************************************************************
	 *  - Method 			: viewStatusById
	 *  - Input Parameters  : integer
	 *  - Return Type 		: DoctorAppointment
	 *  - Author		    : DHRUVI DOSHI 
	 *  - Creation Date     : 30/11/2017
	 *  - Description       : validate all details that come from user
	 ***************************************************************************************/
	@Override
	public DoctorAppointment viewStatusById(int viewId) throws ClientException {
		DoctorAppointment bean = new DoctorAppointment();
		bean = patientDao.viewStatusById(viewId);
		return bean;
	}

	/*************************************************************************************
	 *  - Method 			: validatePatientDetails()
	 *  - Input Parameters  : DoctorAppointment
	 *  - Return Type 		: boolean
	 *  - Author		    : DHRUVI DOSHI 
	 *  - Creation Date     : 30/11/2017
	 *  - Description       : validate all details that come from user
	 ***************************************************************************************/
	@Override
	public boolean validatePatientDetails(DoctorAppointment bean)
			throws ClientException
	{
		boolean validate = false;
		List<String> validationErrors = new ArrayList<String>();
	
		if(!(validateName(bean.getPatient_name()) ))
		{
			validationErrors.add("\n Client Name Should Be In Alphabets and minimum 4 characters long and max 20 characters long! \n");
		}
		
		if(!(validatePhone(bean.getPhone_number())))
		{
			validationErrors.add("\n Contact number should be exact 10 digits! \n");
		}

		if(!(validateEmail(bean.getEmail())))
		{
			validationErrors.add("\n Email id should be proper and max 50 characters long!\n" );
		}
		if(!(validateAge(bean.getAge())))
		{
			validationErrors.add("\n Age must be greater than zero!\n" );
		}
		if(!(validateProblemName(bean.getProblem_name())))
		{
			validationErrors.add("\n Problem name should be proper and in string format!\n" );
		}
		if(!validationErrors.isEmpty())
		{
			throw new ClientException(validationErrors +"");
		}
		else
		{
			validate = true;
		}
		return validate;
	}

	/*************************************************************************************
	 *  - Method 			: validateName()
	 *  - Input Parameters  : String
	 *  - Return Type 		: boolean
	 *  - Author		    : DHRUVI DOSHI 
	 *  - Creation Date     : 30/11/2017
	 *  - Description       : validate name 
	 ***************************************************************************************/
	@Override
	public boolean validateName(String name) throws ClientException 
	{
		Pattern pattern =Pattern.compile("[A-Z][A-Za-z]{3,20}");
		Matcher matcher= pattern.matcher(name);
		return matcher.matches();
	}

	/*************************************************************************************
	 *  - Method 			: validatePhone()
	 *  - Input Parameters  : String
	 *  - Return Type 		: boolean
	 *  - Author		    : DHRUVI DOSHI 
	 *  - Creation Date     : 30/11/2017
	 *  - Description       : validate contact number
	 ***************************************************************************************/
	@Override
	public boolean validatePhone(String phone) throws ClientException
	{
		Pattern pattern =Pattern.compile("[1-9][0-9]{9}");
		Matcher matcher= pattern.matcher(phone);
		return matcher.matches();	
	}

	/*************************************************************************************
	 *  - Method 			: validateEmail()
	 *  - Input Parameters  : String
	 *  - Return Type 		: boolean
	 *  - Author		    : DHRUVI DOSHI 
	 *  - Creation Date     : 30/11/2017
	 *  - Description       : validate email id
	 ***************************************************************************************/
	@Override
	public boolean validateEmail(String email) throws ClientException {
		Pattern pattern =Pattern.compile("\\b[\\w.%-]+@[-.\\w]+\\.[A-Za-z]{2,4}\\b");
		Matcher matcher= pattern.matcher(email);
		return matcher.matches();
	}
	
	/*************************************************************************************
	 *  - Method 			: validateProblemName()
	 *  - Input Parameters  : DoctorAppointment
	 *  - Return Type 		: boolean
	 *  - Author		    : DHRUVI DOSHI 
	 *  - Creation Date     : 30/11/2017
	 *  - Description       : validate problem name
	 ***************************************************************************************/
	@Override
	public boolean validateProblemName(String name) throws ClientException 
	{
		Pattern pattern =Pattern.compile("[A-Za-z]{3,25}");
		Matcher matcher= pattern.matcher(name);
		return matcher.matches();
	}
	/*************************************************************************************
	 *  - Method 			: validateAge()
	 *  - Input Parameters  : integer
	 *  - Return Type 		: boolean
	 *  - Author		    : DHRUVI DOSHI 
	 *  - Creation Date     : 30/11/2017
	 *  - Description       : validate all details that come from user
	 ***************************************************************************************/
	@Override
	public boolean validateAge(int age) throws ClientException 
	{
	 if (age>0)
		 return true;
	 else
		 return false;
	}
}
