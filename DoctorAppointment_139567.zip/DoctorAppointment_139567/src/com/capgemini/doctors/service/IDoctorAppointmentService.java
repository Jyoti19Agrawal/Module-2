package com.capgemini.doctors.service;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.ClientException;

/*************************************************************************************
 *  - Interface			: PatientService 
 *  - Methods           :  addpatientAppointment(PatientBean), viewStatusById(viewId),
 	 					   validatePatientDetails(PatientBean),
 	 					   validating name, phone ,email ,age, gender fields
 *  - Author		    : DHRUVI DOSHI 
 *  - Creation Date     : 30/11/2017
 *  - Description       : declare the above methods that will be implemented 
   						  by sub classes
 ***************************************************************************************/

public interface IDoctorAppointmentService {

	public int addpatientAppointment(DoctorAppointment bean) throws ClientException;
	public DoctorAppointment viewStatusById(int viewId) throws ClientException;
	public boolean validatePatientDetails(DoctorAppointment bean) throws ClientException;
	public boolean validateName(String name) throws ClientException;
	public boolean validatePhone(String phone) throws ClientException ;
	public boolean validateEmail(String email) throws ClientException;
	public boolean validateAge(int age) throws ClientException;
	boolean validateProblemName(String name) throws ClientException;
}
