package com.capgemini.doctors.exception;

/*************************************************************************************
 *  - Exception         : ClientException
 *  - Method 			: Parameterized Constructor
 *  - Input Parameters  : String
 *  - Author		    : DHRUVI DOSHI 
 *  - Creation Date     : 30/11/2017
 *  - Description       : User defined exception- ClientException
 ***************************************************************************************/

public class ClientException extends Exception
{
	//default serial version URL
	private static final long serialVersionUID = 1L;
	
	public ClientException(String message) 
	{
		super(message);	
	}
}
