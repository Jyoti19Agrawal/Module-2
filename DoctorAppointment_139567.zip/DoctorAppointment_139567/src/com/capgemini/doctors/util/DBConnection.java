package com.capgemini.doctors.util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.capgemini.doctors.exception.ClientException;

/*************************************************************************************
 *  - Exception         : @throws PatientException
 *  - Method 			: getConnection() 
 *  - Input Parameters  : 
 *  - Return Type 		: DBConnection instance
 *  - Author		    : DHRUVI DOSHI 
 *  - Creation Date     : 30/11/2017
 *  - Description       : Loads the  jdbc.properties file and Driver Class and 
                          gets the connection
 ***************************************************************************************/


public class DBConnection
{
	//default constructor
	public DBConnection(){
	}
	
	public static Connection getConnection() throws ClientException {
		
		Connection con=null;
		Properties props = new Properties();
		
		try {
			FileReader fr = new FileReader("resources/jdbc.properties");
			props.load(fr);
			String url=props.getProperty("jdbcurl");
			String user =props.getProperty("user");
			String pass=props.getProperty("pass");
			con=DriverManager.getConnection(url, user, pass);
		} 
		catch (FileNotFoundException e){
			throw new ClientException("jdbc.properties file not found");
		} 
		catch (IOException e) {
			throw new ClientException("unable to read jdbc.properties");
		} 
		catch (SQLException e) {
			throw new ClientException("unable to connect to database");
		}
		return con;
	}
}
