package com.capgemini.doctors.ui;

import java.util.Scanner;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.ClientException;
import com.capgemini.doctors.service.IDoctorAppointmentService;
import com.capgemini.doctors.service.DoctorAppointmentService;

/**************************************************************************************
 *  - Class			    : Client (main class)
 *  - Author		    : DHRUVI DOSHI 
 *  - Creation Date     : 30/11/2017
 *  - Description       : get input from user and give appropriate output to user
 ***************************************************************************************/
public class Client {

	public static void main(String[] args) 
	{	
		int ch;
		Scanner sc = new Scanner (System.in);
		do
		{
			System.out.println("1.Book Doctor Appointment");
			System.out.println("2.View Doctor Appointment Status");
			System.out.println("3.Exit");
			int choice = sc.nextInt();
		
		switch(choice)
		{
		case 1:
			System.out.print("Enter Name of Patient   : ");
			String name = sc.next();
			System.out.print("Enter Phone Number      : ");
			String contact = sc.next();
			System.out.print("Enter Email id          : ");
			String email = sc.next();
			System.out.print("Enter Age               : ");
			int age = sc.nextInt();
			System.out.print("Enter Gender            : ");
			String gender = sc.next();
			System.out.print("Enter Problem Name      : ");
			String problem= sc.next();
		
			DoctorAppointment bean = new DoctorAppointment();
			bean.setPatient_name(name);;
			bean.setPhone_number(contact);
			bean.setEmail(email);
			bean.setAge(age);
			bean.setGender(gender);
			bean.setProblem_name(problem);
			
			IDoctorAppointmentService service = new DoctorAppointmentService();
			
			try
			{
				if(service.validatePatientDetails(bean))
				{
				int apnmt_id = service.addpatientAppointment(bean);
				System.out.println("Your Doctor Appointment has been successfully registered!");
				System.out.println("Your appointment ID is : "+apnmt_id);
				}
			    }
				catch (ClientException e) 
				{	
					System.out.println(e);
				}
				break;
			
		case 2:
			System.out.print("Enter the appointment Id : ");
			int viewId = sc.nextInt();
			IDoctorAppointmentService service2 = new DoctorAppointmentService();
			
			try {
				DoctorAppointment bean1  =service2.viewStatusById(viewId);
				System.out.println("The details of id : "+viewId+"\n"+"***************************");
				System.out.println(bean1.toString());
			}
			catch (ClientException e) {
				System.out.println(e);
			}
			break;
		
		case 3:
			break;
		
		default:	
			System.out.println("enter valid choice!");
		}
		System.out.println("\n->Enter 1 for continue.\n->Enter 2 for exit");
		ch = sc.nextInt();
		
		} while(ch==1);
		System.out.println("Thank you for visiting us!");
		sc.close();
	}
}
