package com.capgemini.doctors.bean;

import java.util.Date;

/**************************************************************************************
 *  - Class			    : DoctorAppointment 
 *  - Author		    : DHRUVI DOSHI 
 *  - Creation Date     : 30/11/2017
 *  - Description       : get details from user and set it to object and
                          display info to user
 ***************************************************************************************/

public class DoctorAppointment 
{
	private int appointment_id;
	private String patient_name;
	private String phone_number;
	private Date date_of_appointment;
	private String email;
	private int age;
	private String gender;
	private String problem_name;
	private String doctor_name;
	private String appointment_status;
	public int getAppointment_id() {
		return appointment_id;
	}
	public void setAppointment_id(int appointment_id) {
		this.appointment_id = appointment_id;
	}
	public String getPatient_name() {
		return patient_name;
	}
	public void setPatient_name(String patient_name) {
		this.patient_name = patient_name;
	}
	public String getPhone_number() {
		return phone_number;
	}
	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}
	public Date getDate_of_appointment() {
		return date_of_appointment;
	}
	public void setDate_of_appointment(Date date_of_appointment) {
		this.date_of_appointment = date_of_appointment;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getProblem_name() {
		return problem_name;
	}
	public void setProblem_name(String problem_name) {
		this.problem_name = problem_name;
	}
	public String getDoctor_name() {
		return doctor_name;
	}
	public void setDoctor_name(String doctor_name) {
		this.doctor_name = doctor_name;
	}
	public String getAppointment_status() {
		return appointment_status;
	}
	public void setAppointment_status(String appointment_status) {
		this.appointment_status = appointment_status;
	}
	
/*************************************************************************************
 *  - Method 			: toString() - Override the toString() method of Object class
 *  - Input Parameters  : 
 *  - Return Type 		: String
 *  - Author		    : DHRUVI DOSHI 
 *  - Creation Date     : 30/11/2017
 *  - Description       : display information to user
 ***************************************************************************************/
	
	@Override
	public String toString() {
		return    " patient_name         : " + patient_name
				+ "\n date_of_appointment  : " + date_of_appointment
				+ "\n doctor_name          : " + doctor_name 
				+ "\n appointment_status   : " + appointment_status +"\n";
	}
	
	
	
}
